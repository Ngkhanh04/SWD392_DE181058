/**
 * ========================================
 * DATABASE CONFIG - KẾT NỐI MONGODB
 * ========================================
 * 
 * File này chứa hàm kết nối đến MongoDB
 * Sử dụng Mongoose để quản lý connection
 */

import mongoose from 'mongoose';

/**
 * Kết nối đến MongoDB
 * 
 * @returns {Promise<void>}
 * 
 * Sử dụng trong app.js:
 * import connectDB from './config/database.js';
 * await connectDB();
 */
const connectDB = async () => {
  try {
    // Kết nối MongoDB với URI từ biến môi trường
    const conn = await mongoose.connect(process.env.MONGODB_URI);

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);
    // Thoát process với mã lỗi 1
    process.exit(1);
  }
};

export default connectDB;
