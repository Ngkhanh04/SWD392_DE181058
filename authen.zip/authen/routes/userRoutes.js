/**
 * ========================================
 * USER ROUTES - CÁC TRANG DASHBOARD
 * ========================================
 * 
 * Sử dụng middleware authenticate và authorize
 * để bảo vệ các route theo role
 */

import express from 'express';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// ========================================
// TRANG ADMIN - /admin/users
// ========================================
/**
 * Route này yêu cầu:
 * 1. authenticate - Phải đăng nhập
 * 2. authorize('admin') - Phải có role = 'admin'
 * 
 * Hiển thị danh sách tất cả users
 */
router.get('/admin/users', authenticate, authorize('admin'), (req, res) => {
  // Lấy danh sách users từ app.locals
  const users = req.app.locals.users;
  
  // Render trang admin với danh sách users
  res.render('admin-users', { 
    users: users,
    currentUser: req.user 
  });
});

// ========================================
// TRANG USER - /user/profile
// ========================================
/**
 * Route này yêu cầu:
 * 1. authenticate - Phải đăng nhập
 * 2. authorize('user') - Phải có role = 'user'
 * 
 * Chỉ hiển thị thông tin của chính user đang đăng nhập
 */
router.get('/user/profile', authenticate, authorize('user'), (req, res) => {
  // Render trang profile với thông tin user hiện tại
  res.render('user-profile', { 
    user: req.user 
  });
});

export default router;
