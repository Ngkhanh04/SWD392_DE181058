/**
 * ========================================
 * AUTH ROUTES - ĐĂNG KÝ, ĐĂNG NHẬP, REFRESH TOKEN
 * ========================================
 * 
 * Routes:
 * POST /auth/register - Đăng ký tài khoản mới
 * POST /auth/login    - Đăng nhập
 * POST /auth/refresh  - Refresh access token
 * POST /auth/logout   - Đăng xuất
 * GET  /auth/me       - Lấy thông tin user hiện tại (protected)
 */

import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

// ========================================
// HÀM HỖ TRỢ: TẠO ACCESS TOKEN
// ========================================
/**
 * Tạo JWT access token
 * Access token có thời hạn ngắn (15 phút)
 * 
 * @param {string} userId - ID của user
 * @returns {string} JWT token
 */
const generateAccessToken = (userId) => {
  return jwt.sign(
    { userId }, // QUAN TRỌNG: Payload chỉ dùng userId, không dùng id
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRE || '15m' }
  );
};

// ========================================
// HÀM HỖ TRỢ: TẠO REFRESH TOKEN
// ========================================
/**
 * Tạo JWT refresh token
 * Refresh token có thời hạn dài hơn (7 ngày)
 * Dùng để cấp access token mới khi access token hết hạn
 * 
 * @param {string} userId - ID của user
 * @returns {string} JWT token
 */
const generateRefreshToken = (userId) => {
  return jwt.sign(
    { userId }, // QUAN TRỌNG: Payload chỉ dùng userId
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRE || '7d' }
  );
};

// ========================================
// HÀM HỖ TRỢ: GỬI RESPONSE VỚI TOKEN
// ========================================
/**
 * Gửi response với cả access token và refresh token
 * Refresh token được set vào httpOnly cookie để bảo mật
 * 
 * @param {Object} user - User document từ MongoDB
 * @param {number} statusCode - HTTP status code
 * @param {Object} res - Express response object
 */
const sendTokenResponse = async (user, statusCode, res) => {
  // Tạo tokens
  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);

  // Lưu refresh token vào database
  // Điều này cho phép ta có thể revoke token khi cần
  user.refreshToken = refreshToken;
  await user.save({ validateBeforeSave: false });

  // Cookie options cho refresh token
  const cookieOptions = {
    httpOnly: true, // QUAN TRỌNG: Không cho JS truy cập cookie
    secure: process.env.NODE_ENV === 'production', // Chỉ gửi qua HTTPS trong production
    sameSite: 'strict', // Chống CSRF
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 ngày
  };

  // Tạo object user không chứa password để trả về
  const userResponse = {
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role
  };

  // Gửi response
  res
    .status(statusCode)
    .cookie('refreshToken', refreshToken, cookieOptions) // Set httpOnly cookie
    .json({
      success: true,
      data: {
        user: userResponse,
        accessToken, // Access token trả về trong body
        // Không trả về refresh token trong body vì đã set trong cookie
      }
    });
};

// ========================================
// ROUTE: ĐĂNG KÝ TÀI KHOẢN
// POST /auth/register
// ========================================
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // ========================================
    // VALIDATION
    // ========================================
    
    // Kiểm tra các trường bắt buộc
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Vui lòng nhập đầy đủ tên, email và mật khẩu'
      });
    }

    // Kiểm tra email đã tồn tại chưa
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Email đã được sử dụng'
      });
    }

    // ========================================
    // XỬ LÝ ROLE
    // ========================================
    
    // Không cho phép đăng ký với role admin
    // Admin chỉ có thể được tạo bởi admin khác hoặc qua database
    let userRole = role;
    if (role === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Không thể tự đăng ký với role admin'
      });
    }

    // Chỉ cho phép role customer hoặc owner
    if (role && !['customer', 'owner'].includes(role)) {
      return res.status(400).json({
        success: false,
        message: 'Role không hợp lệ. Chỉ chấp nhận: customer, owner'
      });
    }

    // ========================================
    // TẠO USER MỚI
    // ========================================
    
    const user = await User.create({
      name,
      email,
      password, // Password sẽ được hash trong pre-save middleware
      role: userRole || 'customer' // Mặc định là customer
    });

    // Gửi response với tokens
    await sendTokenResponse(user, 201, res);
  } catch (error) {
    console.error('Register error:', error);

    // Xử lý lỗi validation từ Mongoose
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join('. ')
      });
    }

    // Xử lý lỗi duplicate key (email đã tồn tại)
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Email đã được sử dụng'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Lỗi server khi đăng ký'
    });
  }
});

// ========================================
// ROUTE: ĐĂNG NHẬP
// POST /auth/login
// ========================================
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // ========================================
    // VALIDATION
    // ========================================
    
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Vui lòng nhập email và mật khẩu'
      });
    }

    // ========================================
    // TÌM USER VÀ KIỂM TRA PASSWORD
    // ========================================
    
    // QUAN TRỌNG: Phải dùng .select('+password') vì password có select: false trong schema
    const user = await User.findOne({ email }).select('+password');

    // Kiểm tra user tồn tại
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Email hoặc mật khẩu không đúng'
      });
    }

    // Kiểm tra password
    // Dùng method comparePassword đã định nghĩa trong schema
    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Email hoặc mật khẩu không đúng'
      });
    }

    // ========================================
    // GỬI RESPONSE VỚI TOKENS
    // ========================================
    
    await sendTokenResponse(user, 200, res);
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Lỗi server khi đăng nhập'
    });
  }
});

// ========================================
// ROUTE: REFRESH ACCESS TOKEN
// POST /auth/refresh
// ========================================
router.post('/refresh', async (req, res) => {
  try {
    // ========================================
    // LẤY REFRESH TOKEN TỪ COOKIE HOẶC BODY
    // ========================================
    
    const refreshToken =
      req.cookies?.refreshToken || req.body.refreshToken;

    if (!refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Không tìm thấy refresh token'
      });
    }

    // ========================================
    // VERIFY REFRESH TOKEN
    // ========================================
    
    let decoded;
    try {
      decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    } catch (jwtError) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token không hợp lệ hoặc đã hết hạn'
      });
    }

    // ========================================
    // TÌM USER VÀ KIỂM TRA REFRESH TOKEN
    // ========================================
    
    // QUAN TRỌNG: Dùng decoded.userId (không phải decoded.id)
    const user = await User.findById(decoded.userId).select('+refreshToken');

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User không tồn tại'
      });
    }

    // Kiểm tra refresh token có khớp với token trong database không
    // Điều này cho phép revoke token khi cần
    if (user.refreshToken !== refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token không hợp lệ'
      });
    }

    // ========================================
    // TẠO ACCESS TOKEN MỚI
    // ========================================
    
    const newAccessToken = generateAccessToken(user._id);

    res.status(200).json({
      success: true,
      data: {
        accessToken: newAccessToken
      }
    });
  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(500).json({
      success: false,
      message: 'Lỗi server khi refresh token'
    });
  }
});

// ========================================
// ROUTE: ĐĂNG XUẤT
// POST /auth/logout
// ========================================
router.post('/logout', protect, async (req, res) => {
  try {
    // ========================================
    // XÓA REFRESH TOKEN TRONG DATABASE
    // ========================================
    
    // Điều này vô hiệu hóa refresh token
    await User.findByIdAndUpdate(req.user._id, {
      refreshToken: null
    });

    // ========================================
    // XÓA COOKIE
    // ========================================
    
    res.clearCookie('refreshToken', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict'
    });

    res.status(200).json({
      success: true,
      message: 'Đăng xuất thành công'
    });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Lỗi server khi đăng xuất'
    });
  }
});

// ========================================
// ROUTE: LẤY THÔNG TIN USER HIỆN TẠI
// GET /auth/me
// Protected route - Cần đăng nhập
// ========================================
router.get('/me', protect, async (req, res) => {
  try {
    // req.user đã được set trong middleware protect
    // Chứa full user document (trừ password)
    
    const user = await User.findById(req.user._id);

    res.status(200).json({
      success: true,
      data: {
        user: {
          _id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt
        }
      }
    });
  } catch (error) {
    console.error('Get me error:', error);
    res.status(500).json({
      success: false,
      message: 'Lỗi server'
    });
  }
});

export default router;
