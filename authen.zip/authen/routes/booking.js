/**
 * ========================================
 * BOOKING ROUTES - VÍ DỤ SỬ DỤNG PROTECT VÀ AUTHORIZE
 * ========================================
 * 
 * File này minh họa cách sử dụng middleware protect và authorize
 * trong một route thực tế (booking)
 * 
 * Cấu trúc quyền:
 * - customer: Có thể tạo và xem booking của mình
 * - owner: Có thể xem booking của khách và cập nhật trạng thái
 * - admin: Có toàn quyền
 */

import express from 'express';
import { protect, authorize } from '../middleware/auth.js';

const router = express.Router();

// ========================================
// VÍ DỤ 1: ROUTE CHỈ CẦN ĐĂNG NHẬP
// ========================================
/**
 * GET /bookings/my
 * 
 * Route này chỉ cần user đăng nhập
 * Bất kỳ user nào đã đăng nhập đều có thể truy cập
 * 
 * Middleware: protect
 */
router.get('/my', protect, async (req, res) => {
  try {
    // req.user được set bởi middleware protect
    // Chứa thông tin user đã đăng nhập
    
    // Ví dụ: Tìm booking của user hiện tại
    // const bookings = await Booking.find({ user: req.user._id });

    res.status(200).json({
      success: true,
      message: `Danh sách booking của user ${req.user.name}`,
      data: {
        userId: req.user._id,
        userRole: req.user.role,
        bookings: [] // Thay bằng dữ liệu thực từ database
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi server'
    });
  }
});

// ========================================
// VÍ DỤ 2: ROUTE CHỈ DÀNH CHO CUSTOMER
// ========================================
/**
 * POST /bookings
 * 
 * Chỉ customer mới có thể tạo booking
 * 
 * Middleware: protect -> authorize('customer')
 * 
 * Lưu ý: authorize PHẢI đi SAU protect vì nó cần req.user
 */
router.post(
  '/',
  protect, // Bước 1: Xác thực token
  authorize('customer'), // Bước 2: Kiểm tra role
  async (req, res) => {
    try {
      // Chỉ customer mới vào được đây
      
      res.status(201).json({
        success: true,
        message: 'Tạo booking thành công (chỉ customer)'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Lỗi server'
      });
    }
  }
);

// ========================================
// VÍ DỤ 3: ROUTE DÀNH CHO OWNER VÀ ADMIN
// ========================================
/**
 * GET /bookings/all
 * 
 * Owner và Admin có thể xem tất cả booking
 * 
 * Middleware: protect -> authorize('owner', 'admin')
 * 
 * Cách dùng: authorize có thể nhận nhiều role
 */
router.get(
  '/all',
  protect,
  authorize('owner', 'admin'), // Cho phép cả owner và admin
  async (req, res) => {
    try {
      // Owner hoặc Admin mới vào được đây
      
      res.status(200).json({
        success: true,
        message: `Danh sách tất cả booking (cho ${req.user.role})`,
        data: {
          bookings: [] // Thay bằng dữ liệu thực từ database
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Lỗi server'
      });
    }
  }
);

// ========================================
// VÍ DỤ 4: ROUTE CHỈ DÀNH CHO ADMIN
// ========================================
/**
 * DELETE /bookings/:id
 * 
 * Chỉ Admin mới có thể xóa booking
 * 
 * Middleware: protect -> authorize('admin')
 */
router.delete(
  '/:id',
  protect,
  authorize('admin'), // Chỉ admin
  async (req, res) => {
    try {
      const { id } = req.params;

      // Ví dụ: Xóa booking
      // await Booking.findByIdAndDelete(id);

      res.status(200).json({
        success: true,
        message: `Đã xóa booking ${id} (chỉ admin)`
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Lỗi server'
      });
    }
  }
);

// ========================================
// VÍ DỤ 5: ROUTE CHO NHIỀU ROLE VỚI XỬ LÝ KHÁC NHAU
// ========================================
/**
 * PUT /bookings/:id/status
 * 
 * Owner có thể cập nhật trạng thái booking
 * Admin có thể cập nhật bất kỳ thông tin nào
 * 
 * Middleware: protect -> authorize('owner', 'admin')
 */
router.put(
  '/:id/status',
  protect,
  authorize('owner', 'admin'),
  async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      // Xử lý khác nhau dựa trên role
      if (req.user.role === 'owner') {
        // Owner chỉ có thể cập nhật status
        // Ví dụ: pending -> confirmed, confirmed -> cancelled
        
        res.status(200).json({
          success: true,
          message: `Owner đã cập nhật status booking ${id} thành ${status}`
        });
      } else if (req.user.role === 'admin') {
        // Admin có thể làm nhiều hơn
        
        res.status(200).json({
          success: true,
          message: `Admin đã cập nhật booking ${id}`
        });
      }
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Lỗi server'
      });
    }
  }
);

// ========================================
// TÓM TẮT CÁCH SỬ DỤNG
// ========================================
/**
 * 1. Import middleware:
 *    import { protect, authorize } from '../middleware/auth.js';
 * 
 * 2. Chỉ cần đăng nhập:
 *    router.get('/route', protect, handler);
 * 
 * 3. Cần đăng nhập + role cụ thể:
 *    router.get('/route', protect, authorize('admin'), handler);
 * 
 * 4. Cần đăng nhập + nhiều role:
 *    router.get('/route', protect, authorize('owner', 'admin'), handler);
 * 
 * QUAN TRỌNG:
 * - authorize PHẢI đi SAU protect
 * - Trong handler, req.user chứa thông tin user đã đăng nhập
 * - req.user.role cho biết role của user
 */

export default router;
