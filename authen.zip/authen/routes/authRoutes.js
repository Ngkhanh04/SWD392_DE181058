/**
 * ========================================
 * AUTH ROUTES - ĐĂNG NHẬP / ĐĂNG XUẤT
 * ========================================
 */

import express from 'express';
import jwt from 'jsonwebtoken';

const router = express.Router();

// ========================================
// GET /login - Hiển thị form đăng nhập
// ========================================
router.get('/login', (req, res) => {
  // Render trang login với error = null (không có lỗi)
  res.render('login', { error: null });
});

// ========================================
// POST /login - Xử lý đăng nhập
// ========================================
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Tìm user trong mock data
  const user = req.app.locals.users.find(
    u => u.email === email && u.password === password
  );

  // Nếu không tìm thấy user -> Sai email hoặc password
  if (!user) {
    return res.render('login', { 
      error: 'Email hoặc mật khẩu không đúng!' 
    });
  }

  // Tạo JWT token chứa id và role của user
  const token = jwt.sign(
    { id: user.id, role: user.role },
    req.app.locals.JWT_SECRET,
    { expiresIn: '1h' } // Token hết hạn sau 1 giờ
  );

  // Lưu token vào Cookie với httpOnly: true để bảo mật
  res.cookie('token', token, {
    httpOnly: true,  // JavaScript không thể truy cập cookie này
    maxAge: 3600000  // 1 giờ (tính bằng milliseconds)
  });

  // Điều hướng dựa trên role
  if (user.role === 'admin') {
    return res.redirect('/admin/users');
  } else {
    return res.redirect('/user/profile');
  }
});

// ========================================
// GET /logout - Xử lý đăng xuất
// ========================================
router.get('/logout', (req, res) => {
  // Xóa cookie token
  res.clearCookie('token');
  
  // Quay về trang login
  res.redirect('/login');
});

export default router;
