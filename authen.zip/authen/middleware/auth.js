/**
 * ========================================
 * AUTHENTICATION MIDDLEWARE
 * ========================================
 * 
 * File này chứa các middleware để:
 * 1. authenticate - Xác thực JWT token từ cookie
 * 2. authorize(role) - Kiểm tra role của user
 */

import jwt from 'jsonwebtoken';

// ========================================
// MIDDLEWARE: AUTHENTICATE - XÁC THỰC
// ========================================
/**
 * Kiểm tra xem người dùng có Token trong Cookie hay không
 * Nếu không có hoặc token sai -> redirect về trang /login
 */
export const authenticate = (req, res, next) => {
  try {
    // Lấy token từ cookie
    const token = req.cookies.token;

    // Nếu không có token -> Redirect về login
    if (!token) {
      return res.redirect('/login');
    }

    // Verify token
    const decoded = jwt.verify(token, req.app.locals.JWT_SECRET);

    // Tìm user trong mock data
    const user = req.app.locals.users.find(u => u.id === decoded.id);

    if (!user) {
      return res.redirect('/login');
    }

    // Gắn user vào request để các route handler có thể sử dụng
    req.user = user;

    next();
  } catch (error) {
    // Token không hợp lệ hoặc hết hạn
    res.clearCookie('token');
    return res.redirect('/login');
  }
};

// ========================================
// MIDDLEWARE: AUTHORIZE - PHÂN QUYỀN
// ========================================
/**
 * Kiểm tra xem role của người dùng có khớp với quyền truy cập không
 * @param {string} role - Role được phép truy cập ('admin' hoặc 'user')
 */
export const authorize = (role) => {
  return (req, res, next) => {
    // Kiểm tra role có khớp không
    if (req.user.role !== role) {
      // Nếu không có quyền, redirect về trang phù hợp
      if (req.user.role === 'admin') {
        return res.redirect('/admin/users');
      } else {
        return res.redirect('/user/profile');
      }
    }

    next();
  };
};

export default { authenticate, authorize };
