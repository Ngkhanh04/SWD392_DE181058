/**
 * ========================================
 * USER MODEL - MongoDB Schema với Mongoose
 * ========================================
 * 
 * Model này định nghĩa cấu trúc dữ liệu User trong MongoDB
 * Bao gồm:
 * - Schema definition
 * - Pre-save middleware để hash password
 * - Method comparePassword để so sánh password
 */

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

// ========================================
// ĐỊNH NGHĨA SCHEMA
// ========================================

const userSchema = new mongoose.Schema(
  {
    // Tên người dùng
    name: {
      type: String,
      required: [true, 'Vui lòng nhập tên'],
      trim: true, // Tự động xóa khoảng trắng đầu/cuối
      maxlength: [50, 'Tên không được vượt quá 50 ký tự']
    },

    // Email - dùng để đăng nhập
    email: {
      type: String,
      required: [true, 'Vui lòng nhập email'],
      unique: true, // Không cho phép trùng email
      lowercase: true, // Tự động chuyển về chữ thường
      trim: true,
      match: [
        /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
        'Vui lòng nhập email hợp lệ'
      ]
    },

    // Mật khẩu - select: false để không trả về trong query mặc định
    password: {
      type: String,
      required: [true, 'Vui lòng nhập mật khẩu'],
      minlength: [6, 'Mật khẩu phải có ít nhất 6 ký tự'],
      select: false // QUAN TRỌNG: Không trả về password trong query mặc định
    },

    // Vai trò người dùng
    role: {
      type: String,
      enum: {
        values: ['customer', 'owner', 'admin'],
        message: 'Role không hợp lệ'
      },
      default: 'customer' // Mặc định là customer
    },

    // Refresh token - dùng để cấp access token mới
    refreshToken: {
      type: String,
      select: false // Không trả về trong query mặc định
    }
  },
  {
    timestamps: true // Tự động thêm createdAt và updatedAt
  }
);

// ========================================
// PRE-SAVE MIDDLEWARE - HASH PASSWORD
// ========================================
/**
 * Middleware này chạy TRƯỚC khi document được save vào database
 * Chỉ hash password nếu password đã bị thay đổi (hoặc mới tạo)
 */
userSchema.pre('save', async function (next) {
  // Kiểm tra xem password có bị modify không
  // Nếu không thì bỏ qua, không hash lại
  if (!this.isModified('password')) {
    return next();
  }

  // Hash password với salt round = 10
  // Salt round càng cao thì càng bảo mật nhưng càng chậm
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);

  next();
});

// ========================================
// INSTANCE METHOD - SO SÁNH PASSWORD
// ========================================
/**
 * Method này được gọi trên document instance
 * Dùng để so sánh password người dùng nhập với password đã hash trong DB
 * 
 * @param {string} enteredPassword - Password người dùng nhập
 * @returns {Promise<boolean>} - true nếu khớp, false nếu không
 * 
 * Cách dùng: await user.comparePassword(enteredPassword)
 */
userSchema.methods.comparePassword = async function (enteredPassword) {
  // bcrypt.compare sẽ hash enteredPassword và so sánh với this.password
  return await bcrypt.compare(enteredPassword, this.password);
};

// ========================================
// TẠO VÀ EXPORT MODEL
// ========================================
const User = mongoose.model('User', userSchema);

export default User;
