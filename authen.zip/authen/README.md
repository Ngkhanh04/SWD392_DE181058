# 🔐 Authentication System - Node.js + Express + MongoDB

Hệ thống Authentication hoàn chỉnh với JWT, Refresh Token, HttpOnly Cookie và Role-based Authorization.

## 📁 Cấu trúc thư mục

```
authen/
├── config/
│   └── database.js       # Kết nối MongoDB
├── middleware/
│   └── auth.js           # Middleware protect và authorize
├── models/
│   └── User.js           # User model với hash password
├── routes/
│   ├── auth.js           # Routes: register, login, refresh, logout, me
│   └── booking.js        # Ví dụ sử dụng protect + authorize
├── app.js                # File chính
├── .env                  # Biến môi trường
├── .env.example          # Mẫu biến môi trường
└── package.json
```

## 🚀 Cài đặt và chạy

### 1. Cài đặt dependencies

```bash
npm install
```

### 2. Cấu hình biến môi trường

```bash
# Copy file mẫu
cp .env.example .env

# Sửa file .env với các giá trị phù hợp
```

### 3. Chạy ứng dụng

```bash
# Development mode (với nodemon)
npm run dev

# Production mode
npm start
```

## 📡 API Endpoints

### Authentication

| Method | Endpoint | Mô tả | Auth |
|--------|----------|-------|------|
| POST | `/auth/register` | Đăng ký tài khoản | ❌ |
| POST | `/auth/login` | Đăng nhập | ❌ |
| POST | `/auth/refresh` | Refresh access token | ❌ |
| POST | `/auth/logout` | Đăng xuất | ✅ |
| GET | `/auth/me` | Lấy thông tin user | ✅ |

### Booking (Ví dụ)

| Method | Endpoint | Mô tả | Role |
|--------|----------|-------|------|
| GET | `/bookings/my` | Xem booking của mình | Tất cả |
| POST | `/bookings` | Tạo booking | customer |
| GET | `/bookings/all` | Xem tất cả booking | owner, admin |
| DELETE | `/bookings/:id` | Xóa booking | admin |
| PUT | `/bookings/:id/status` | Cập nhật status | owner, admin |

## 🔧 Cách sử dụng API

### 1. Đăng ký

```bash
POST /auth/register
Content-Type: application/json

{
  "name": "Nguyen Van A",
  "email": "nguyenvana@email.com",
  "password": "123456",
  "role": "customer"  // hoặc "owner" (không được đăng ký admin)
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "_id": "...",
      "name": "Nguyen Van A",
      "email": "nguyenvana@email.com",
      "role": "customer"
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### 2. Đăng nhập

```bash
POST /auth/login
Content-Type: application/json

{
  "email": "nguyenvana@email.com",
  "password": "123456"
}
```

### 3. Gọi API protected

```bash
GET /auth/me
Authorization: Bearer <access_token>
```

### 4. Refresh token

```bash
POST /auth/refresh
Content-Type: application/json

{
  "refreshToken": "..." // Hoặc tự động lấy từ httpOnly cookie
}
```

## 🔒 Cách sử dụng Middleware trong Route

### Import middleware

```javascript
import { protect, authorize } from '../middleware/auth.js';
```

### Chỉ cần đăng nhập

```javascript
router.get('/profile', protect, (req, res) => {
  // req.user chứa thông tin user
});
```

### Cần role cụ thể

```javascript
router.delete('/users/:id', protect, authorize('admin'), (req, res) => {
  // Chỉ admin mới vào được
});
```

### Cho phép nhiều role

```javascript
router.get('/reports', protect, authorize('owner', 'admin'), (req, res) => {
  // Owner hoặc Admin mới vào được
});
```

## 📝 Giải thích Token Flow

```
┌─────────────┐                          ┌─────────────┐
│   Client    │                          │   Server    │
└──────┬──────┘                          └──────┬──────┘
       │                                        │
       │  1. POST /auth/login                   │
       │  {email, password}                     │
       │───────────────────────────────────────>│
       │                                        │
       │  2. Response:                          │
       │  - accessToken (body)                  │
       │  - refreshToken (httpOnly cookie)      │
       │<───────────────────────────────────────│
       │                                        │
       │  3. GET /auth/me                       │
       │  Authorization: Bearer <accessToken>   │
       │───────────────────────────────────────>│
       │                                        │
       │  4. User data                          │
       │<───────────────────────────────────────│
       │                                        │
       │  5. Access token hết hạn...            │
       │                                        │
       │  6. POST /auth/refresh                 │
       │  (cookie tự động gửi refreshToken)     │
       │───────────────────────────────────────>│
       │                                        │
       │  7. New accessToken                    │
       │<───────────────────────────────────────│
       │                                        │
```

## ⚠️ Lưu ý quan trọng

1. **Token payload**: Luôn dùng `{ userId }`, không dùng `{ id }`
2. **Password**: Có `select: false`, khi login phải dùng `.select('+password')`
3. **Middleware order**: `authorize` phải đi SAU `protect`
4. **Admin**: Không cho phép user tự đăng ký admin
5. **Refresh token**: Lưu trong httpOnly cookie để bảo mật

## 🛡️ Bảo mật

- Password được hash bằng bcryptjs (salt round = 10)
- Access token có thời hạn ngắn (15 phút)
- Refresh token lưu trong httpOnly cookie
- CORS được cấu hình với credentials
- Token có thể bị revoke khi logout

## 📚 Công nghệ sử dụng

- **Node.js** - Runtime
- **Express** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **cookie-parser** - Parse cookies

## ✅ Test với Postman/Thunder Client

1. **Tạo admin bằng cách thêm trực tiếp vào MongoDB**:
```javascript
// Trong MongoDB Compass hoặc shell
db.users.insertOne({
  name: "Admin",
  email: "admin@email.com",
  password: "$2a$10$...", // Hash từ bcrypt
  role: "admin"
})
```

2. **Hoặc dùng MongoDB Compass** để sửa role của user thành "admin"
