/**
 * ========================================
 * APP.JS - FILE CHÍNH CỦA ỨNG DỤNG
 * ========================================
 * 
 * Simple Authentication System với JWT và EJS
 * - Mock data (không cần database)
 * - JWT token lưu trong httpOnly cookie
 * - Phân quyền Admin/User
 */

import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';

// Import routes
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';

// ========================================
// TẠO EXPRESS APP
// ========================================

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ========================================
// CẤU HÌNH VIEW ENGINE - EJS
// ========================================

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ========================================
// MOCK DATA - DỮ LIỆU GIẢ
// ========================================

// Danh sách users giả lập (thay vì database)
app.locals.users = [
  {
    id: 1,
    name: 'Admin User',
    email: 'admin@mail.com',
    password: 'admin123',
    role: 'admin'
  },
  {
    id: 2,
    name: 'Bob User',
    email: 'bob@mail.com',
    password: 'user123',
    role: 'user'
  }
];

// Secret key cho JWT (trong thực tế nên đặt trong .env)
app.locals.JWT_SECRET = 'my_super_secret_key_12345';

// ========================================
// MIDDLEWARE
// ========================================

// Parse JSON body
app.use(express.json());

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Parse cookies - QUAN TRỌNG cho httpOnly cookie
app.use(cookieParser());

// ========================================
// MOUNT ROUTES
// ========================================

// Auth routes - Đăng nhập, Đăng xuất
app.use('/', authRoutes);

// User routes - Dashboard Admin/User
app.use('/', userRoutes);

// Route gốc - redirect về login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// ========================================
// ERROR HANDLER - XỬ LÝ LỖI
// ========================================

// 404 - Trang không tìm thấy
app.use((req, res) => {
  res.status(404).send('Trang không tồn tại');
});

// ========================================
// START SERVER
// ========================================

const PORT = 5000;

app.listen(PORT, () => {
  console.log(`
========================================
🚀 Server đang chạy tại http://localhost:${PORT}
========================================
📧 Admin: admin@mail.com / admin123
📧 User: bob@mail.com / user123
========================================
  `);
});

export default app;
